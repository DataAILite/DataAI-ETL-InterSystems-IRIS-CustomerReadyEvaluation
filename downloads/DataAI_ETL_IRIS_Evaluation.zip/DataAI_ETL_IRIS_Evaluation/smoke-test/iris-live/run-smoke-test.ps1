[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$IrisJdbcJar,

    [string]$JdbcUrl = 'jdbc:IRIS://localhost:1972/USER',
    [string]$IrisUser,
    [string]$SparkSubmit = 'spark-submit.cmd'
)

$ErrorActionPreference = 'Stop'
$packageRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$version = '0.1.0-SNAPSHOT'
$applicationJar = Join-Path $PSScriptRoot "dataai-iris-evaluation-smoke-test-$version.jar"
$dataAiJars = @(
    (Join-Path $packageRoot "lib\dataai-spark-api-$version.jar"),
    (Join-Path $packageRoot "lib\dataai-spark-quality-$version.jar"),
    (Join-Path $packageRoot "lib\dataai-spark-core-$version.jar"),
    (Join-Path $packageRoot "lib\dataai-spark-functions-$version.jar"),
    (Join-Path $packageRoot "lib\dataai-spark-iris-$version.jar")
)

foreach ($path in @($applicationJar, $IrisJdbcJar) + $dataAiJars) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Required JAR was not found: $path"
    }
}

$sparkCommand = Get-Command -Name $SparkSubmit -ErrorAction Stop
$sparkExecutable = if ($sparkCommand.Source) { $sparkCommand.Source } else { $sparkCommand.Path }
if (-not $IrisUser) {
    $IrisUser = Read-Host 'IRIS user'
}
if (-not $IrisUser) {
    throw 'IRIS user cannot be blank.'
}

$securePassword = Read-Host 'IRIS password' -AsSecureString
$passwordPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword)
try {
    $irisPassword = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($passwordPointer)
} finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($passwordPointer)
}

$names = @('IRIS_JDBC_URL', 'IRIS_USER', 'IRIS_PASSWORD')
$previous = @{}
foreach ($name in $names) {
    $previous[$name] = [Environment]::GetEnvironmentVariable($name, 'Process')
}

try {
    [Environment]::SetEnvironmentVariable('IRIS_JDBC_URL', $JdbcUrl, 'Process')
    [Environment]::SetEnvironmentVariable('IRIS_USER', $IrisUser, 'Process')
    [Environment]::SetEnvironmentVariable('IRIS_PASSWORD', $irisPassword, 'Process')
    $jars = (@($IrisJdbcJar) + $dataAiJars) -join ','
    & $sparkExecutable `
        --master 'local[2]' `
        --conf 'spark.ui.enabled=false' `
        --conf 'spark.sql.shuffle.partitions=2' `
        --jars $jars `
        --class 'com.dataai.customer.examples.IrisEvaluationSmokeTest' `
        $applicationJar
    if ($LASTEXITCODE -ne 0) {
        throw "DataAI IRIS smoke test failed with exit code $LASTEXITCODE."
    }
} finally {
    foreach ($name in $names) {
        [Environment]::SetEnvironmentVariable($name, $previous[$name], 'Process')
    }
    $irisPassword = $null
    $securePassword = $null
}

Write-Host 'DataAI IRIS evaluation smoke test completed successfully.'
