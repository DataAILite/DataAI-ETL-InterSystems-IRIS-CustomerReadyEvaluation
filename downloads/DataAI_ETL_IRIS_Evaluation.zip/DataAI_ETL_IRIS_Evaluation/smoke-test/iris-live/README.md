# Live IRIS Evaluation Smoke Test

This smoke test proves the delivered DataAI JARs can read fictional rows from
InterSystems IRIS, run DataAI quality processing and matrix balancing, write
customer-selected result tables, and read the persisted results back.

## Prerequisites

- Java 17 and Apache Spark 3.5.0 with `spark-submit` available.
- A running evaluation IRIS instance and an isolated namespace.
- A customer-supplied InterSystems JDBC driver compatible with IRIS and Java.
- An evaluation identity permitted to read `Source` and create/write `DataAI`
  tables in that isolated namespace.

Spark/Hadoop and the InterSystems JDBC driver are not bundled. The ZIP does
include every DataAI JAR needed by the smoke-test application.

## Run

1. Review the evaluation license in the package root.
2. In Management Portal SQL, select the isolated namespace and execute each
   statement in `setup-evaluation.sql` once.
3. Run the test without putting a password in a command or shell history:

   ```powershell
   .\run-smoke-test.ps1 `
     -IrisJdbcJar 'C:\InterSystems\IRIS\dev\java\lib\1.8\intersystems-jdbc-3.10.1.jar' `
     -JdbcUrl 'jdbc:IRIS://localhost:1972/USER'
   ```

4. Enter the evaluation user and password when prompted.
5. Require the marker `DATAAI_IRIS_SMOKE_TEST_PASS` and a zero exit code.
6. Optionally execute `verify-results.sql` in the same namespace.

The expected fictional-data result is six input rows, four accepted rows, two
rejected rows, two quality findings, and four converged matrix cells.
