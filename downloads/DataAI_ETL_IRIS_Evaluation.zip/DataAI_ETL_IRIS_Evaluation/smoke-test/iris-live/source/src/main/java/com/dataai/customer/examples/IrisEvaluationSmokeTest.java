package com.dataai.customer.examples;

import com.dataai.etl.spark.api.DataAiResult;
import com.dataai.etl.spark.api.PipelineSummary;
import com.dataai.etl.spark.api.RuleSpec;
import com.dataai.etl.spark.core.DataAiPipeline;
import com.dataai.etl.spark.functions.MatrixBalanceResult;
import com.dataai.etl.spark.functions.MatrixFunctions;
import com.dataai.etl.spark.iris.IrisDataFrames;
import com.dataai.etl.spark.iris.IrisFunctionOutputs;
import com.dataai.etl.spark.iris.IrisJdbcOptions;
import com.dataai.etl.spark.iris.IrisOutputNames;
import com.dataai.etl.spark.iris.IrisPipelineOutputBundle;
import com.dataai.etl.spark.iris.IrisPipelineOutputs;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.SparkSession;

import java.time.Instant;
import java.util.Arrays;
import java.util.Locale;

import static org.apache.spark.sql.functions.col;

/** Live evaluation check using only fictional data in an isolated IRIS namespace. */
public final class IrisEvaluationSmokeTest {
    private static final long EXPECTED_SOURCE_ROWS = 6;
    private static final long EXPECTED_ACCEPTED_ROWS = 4;
    private static final long EXPECTED_REJECTED_ROWS = 2;
    private static final long EXPECTED_MATRIX_ROWS = 4;

    private IrisEvaluationSmokeTest() {
    }

    public static void main(String[] args) {
        SparkSession spark = SparkSession.builder()
                .appName("DataAI IRIS Evaluation Smoke Test")
                .getOrCreate();
        try {
            IrisJdbcOptions iris = IrisJdbcOptions
                    .builder(requiredEnvironment("IRIS_JDBC_URL"))
                    .credentials(
                            requiredEnvironment("IRIS_USER"),
                            requiredEnvironment("IRIS_PASSWORD"))
                    .fetchSize(1000)
                    .batchSize(500)
                    .build();

            PipelineSummary pipeline = runPipeline(spark, iris);
            runMatrixBalance(spark, iris, pipeline);
            System.out.println("DATAAI_IRIS_SMOKE_TEST_PASS"
                    + " runId=" + pipeline.runId()
                    + " rowsRead=" + pipeline.rowsRead()
                    + " rowsAccepted=" + pipeline.rowsAccepted()
                    + " rowsRejected=" + pipeline.rowsRejected());
        } finally {
            spark.stop();
        }
    }

    private static PipelineSummary runPipeline(SparkSession spark, IrisJdbcOptions iris) {
        Dataset<Row> input = lowerCaseColumns(
                IrisDataFrames.readTable(spark, iris, "Source.CustomerOrders"));
        DataAiResult result = DataAiPipeline.fromDataset(input)
                .normalize()
                .recordKey("order_id")
                .profile()
                .validate(
                        RuleSpec.required("customer-required", "customer_id"),
                        RuleSpec.minimum("amount-nonnegative", "amount", 0))
                .execute();
        PipelineSummary summary = result.summary();
        requireCount("source rows", EXPECTED_SOURCE_ROWS, summary.rowsRead());
        requireCount("accepted rows", EXPECTED_ACCEPTED_ROWS, summary.rowsAccepted());
        requireCount("rejected rows", EXPECTED_REJECTED_ROWS, summary.rowsRejected());

        IrisPipelineOutputBundle output = IrisPipelineOutputs.from(result);
        append(output.pipelineRuns(), iris, IrisOutputNames.PIPELINE_RUNS);
        append(output.qualityFindings(), iris, IrisOutputNames.QUALITY_FINDINGS);
        append(output.fieldProfiles(), iris, IrisOutputNames.FIELD_PROFILES);
        append(output.rejectedRows(), iris, IrisOutputNames.REJECTED_ROWS);
        append(output.cleanRows(), iris, IrisOutputNames.CLEAN_ROWS);

        requireCount("persisted pipeline run", 1,
                countByRun(spark, iris, IrisOutputNames.PIPELINE_RUNS, "run_id", summary.runId()));
        requireCount("persisted clean rows", EXPECTED_ACCEPTED_ROWS,
                countByRun(spark, iris, IrisOutputNames.CLEAN_ROWS,
                        IrisFunctionOutputs.RUN_ID, summary.runId()));
        requireCount("persisted rejected rows", EXPECTED_REJECTED_ROWS,
                countByRun(spark, iris, IrisOutputNames.REJECTED_ROWS,
                        IrisFunctionOutputs.RUN_ID, summary.runId()));
        requireCount("persisted quality findings", EXPECTED_REJECTED_ROWS,
                countByRun(spark, iris, IrisOutputNames.QUALITY_FINDINGS,
                        IrisFunctionOutputs.RUN_ID, summary.runId()));
        long profiles = countByRun(spark, iris, IrisOutputNames.FIELD_PROFILES,
                IrisFunctionOutputs.RUN_ID, summary.runId());
        if (profiles < 1) {
            throw new IllegalStateException("No field profiles were persisted for run " + summary.runId());
        }
        return summary;
    }

    private static void runMatrixBalance(
            SparkSession spark,
            IrisJdbcOptions iris,
            PipelineSummary pipeline) {
        Dataset<Row> cells = lowerCaseColumns(
                IrisDataFrames.readTable(spark, iris, "Source.MatrixCells"));
        Dataset<Row> rowTargets = lowerCaseColumns(
                IrisDataFrames.readTable(spark, iris, "Source.MatrixRowTargets"));
        Dataset<Row> columnTargets = lowerCaseColumns(
                IrisDataFrames.readTable(spark, iris, "Source.MatrixColumnTargets"));
        MatrixBalanceResult balance = MatrixFunctions.balance(
                cells,
                "region",
                "category",
                "value",
                rowTargets,
                columnTargets,
                "target_total",
                20,
                0.001);
        if (!balance.converged()) {
            throw new IllegalStateException(
                    "Matrix balancing did not converge; maximum error=" + balance.maximumError());
        }
        String matrixRunId = pipeline.runId() + "-matrix";
        Dataset<Row> matrixOutput = IrisFunctionOutputs.matrixBalance(
                balance,
                matrixRunId,
                Instant.now(),
                pipeline.libraryVersion());
        requireCount("matrix result rows", EXPECTED_MATRIX_ROWS, matrixOutput.count());
        append(matrixOutput, iris, IrisOutputNames.MATRIX_BALANCE);
        requireCount("persisted matrix rows", EXPECTED_MATRIX_ROWS,
                countByRun(spark, iris, IrisOutputNames.MATRIX_BALANCE,
                        IrisFunctionOutputs.RUN_ID, matrixRunId));
    }

    private static Dataset<Row> lowerCaseColumns(Dataset<Row> input) {
        Dataset<Row> result = input;
        for (String name : input.columns()) {
            String normalized = name.toLowerCase(Locale.ROOT);
            if (!name.equals(normalized)) {
                result = result.withColumnRenamed(name, normalized);
            }
        }
        return result;
    }

    private static long countByRun(
            SparkSession spark,
            IrisJdbcOptions iris,
            String table,
            String requestedColumn,
            String runId) {
        Dataset<Row> persisted = IrisDataFrames.readTable(spark, iris, table);
        String actualColumn = Arrays.stream(persisted.columns())
                .filter(name -> name.equalsIgnoreCase(requestedColumn))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException(
                        "Table " + table + " does not expose column " + requestedColumn));
        return persisted.filter(col(actualColumn).equalTo(runId)).count();
    }

    private static void append(Dataset<Row> output, IrisJdbcOptions iris, String table) {
        IrisDataFrames.writer(output, iris)
                .option("dbtable", table)
                .mode(SaveMode.Append)
                .save();
    }

    private static void requireCount(String name, long expected, long actual) {
        if (actual != expected) {
            throw new IllegalStateException(
                    "Unexpected " + name + ": expected " + expected + " but found " + actual);
        }
    }

    private static String requiredEnvironment(String name) {
        String value = System.getenv(name);
        if (value == null || value.isBlank()) {
            throw new IllegalStateException("Required environment variable is missing: " + name);
        }
        return value;
    }
}
