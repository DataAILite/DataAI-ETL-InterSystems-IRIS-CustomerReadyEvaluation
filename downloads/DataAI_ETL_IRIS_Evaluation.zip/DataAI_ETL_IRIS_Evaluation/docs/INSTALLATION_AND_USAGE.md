# InterSystems IRIS: Customer Evaluation Installation and Usage

This is the customer-ready DataAI ETL evaluation package from Yanbor LLC,
provider of the DataAI product. DataAI runs inside the customer's pipeline; it
is not a hosted service and makes no required DataAI network call.

## Prerequisites

- Java 17
- Apache Spark 3.5.0 with Scala 2.12
- Running InterSystems IRIS instance
- Customer-supplied compatible InterSystems JDBC driver

## Installation and first verification

1. Review LICENSE.md and use an isolated IRIS evaluation namespace.
2. Run smoke-test\run-smoke-test.ps1 for the local DataAI library check.
3. Execute smoke-test\iris-live\setup-evaluation.sql in the isolated namespace.
4. Run smoke-test\iris-live\run-smoke-test.ps1 with the path to the customer-supplied IRIS JDBC driver.
5. Require DATAAI_IRIS_SMOKE_TEST_PASS and inspect the written DataAI tables with verify-results.sql.

## Evaluation boundary

- Use only fictional or approved non-production data.
- Review `LICENSE.md`; the standard evaluation is less than 32 consecutive
  calendar days.
- DataAI software is provided AS IS, with no obligations except those
  expressly accepted in a signed commercial agreement or order form.
- Spark, Hadoop, cloud platforms, BI tools, orchestration products, and vendor
  drivers remain customer-provided and governed by their respective terms.
- A successful local smoke test validates the delivered DataAI artifacts. It
  does not claim certification on the customer's external platform.

## Package layout

- `install/`: platform-specific installer or packages, when applicable.
- `lib/`: DataAI JARs required by Spark-based integrations.
- `smoke-test/` or `nuget-smoke-test/`: executable local verification.
- `docs/`: complete function catalog and product-specific guidance.
- `samples/`: fictional evaluation inputs.
- `platform/`: platform-specific examples, notebooks, configuration, POMs, or
  container-review assets.
- `PACKAGE_CONTENTS.sha256`: SHA-256 for every other file in this ZIP.
