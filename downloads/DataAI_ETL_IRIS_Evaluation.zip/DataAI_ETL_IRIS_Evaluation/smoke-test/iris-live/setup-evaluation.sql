-- Run once in a new, isolated evaluation namespace. All rows are fictional.
-- Execute statements individually when using Management Portal SQL.

CREATE SCHEMA Source;
CREATE SCHEMA DataAI;

CREATE TABLE Source.CustomerOrders (
    order_sequence BIGINT NOT NULL,
    order_id VARCHAR(40) NOT NULL,
    customer_id VARCHAR(40),
    amount DOUBLE,
    email VARCHAR(240),
    status VARCHAR(40),
    order_date VARCHAR(40),
    region VARCHAR(80),
    PRIMARY KEY (order_sequence)
);

INSERT INTO Source.CustomerOrders VALUES
    (1, 'ORD-1001', 'CUST-100', 125.50, 'buyer1@example.test', 'Open', '2026-08-01', 'West');
INSERT INTO Source.CustomerOrders VALUES
    (2, 'ORD-1002', NULL, 50.00, 'buyer2@example.test', 'Open', '2026-08-02', 'Central');
INSERT INTO Source.CustomerOrders VALUES
    (3, 'ORD-1003', 'CUST-300', -10.00, 'invalid-email', 'Pending', '2026-08-03', 'East');
INSERT INTO Source.CustomerOrders VALUES
    (4, 'ORD-1003', 'CUST-301', 75.00, 'buyer4@example.test', 'Closed', '2026-08-04', 'West');
INSERT INTO Source.CustomerOrders VALUES
    (5, 'ORD-1005', 'CUST-500', 310.25, 'buyer5@example.test', 'Closed', 'not-a-date', 'South');
INSERT INTO Source.CustomerOrders VALUES
    (6, 'ORD-1006', 'CUST-600', 42.75, 'buyer6@example.test', 'Open', '2026-08-06', 'North');

CREATE TABLE Source.MatrixCells (
    region VARCHAR(80) NOT NULL,
    category VARCHAR(80) NOT NULL,
    value DOUBLE NOT NULL
);
INSERT INTO Source.MatrixCells VALUES ('North', 'A', 10.0);
INSERT INTO Source.MatrixCells VALUES ('North', 'B', 20.0);
INSERT INTO Source.MatrixCells VALUES ('South', 'A', 30.0);
INSERT INTO Source.MatrixCells VALUES ('South', 'B', 40.0);

CREATE TABLE Source.MatrixRowTargets (
    region VARCHAR(80) NOT NULL,
    target_total DOUBLE NOT NULL
);
INSERT INTO Source.MatrixRowTargets VALUES ('North', 40.0);
INSERT INTO Source.MatrixRowTargets VALUES ('South', 60.0);

CREATE TABLE Source.MatrixColumnTargets (
    category VARCHAR(80) NOT NULL,
    target_total DOUBLE NOT NULL
);
INSERT INTO Source.MatrixColumnTargets VALUES ('A', 50.0);
INSERT INTO Source.MatrixColumnTargets VALUES ('B', 50.0);
