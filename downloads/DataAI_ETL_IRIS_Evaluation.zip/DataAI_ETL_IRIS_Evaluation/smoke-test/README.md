# Local DataAI Library Smoke Test

This test uses only fictional in-memory rows. It starts local Spark, executes
normalization, profiling, required and numeric quality rules, clean/rejected
routing, the complete function-catalog check, and iterative matrix balancing.
The Tableau package additionally verifies its dashboard and matrix adapters.

## Requirements

- Java 17.
- Apache Spark 3.5.0 with Scala 2.12.
- `spark-submit` available on `PATH`, or supplied with `-SparkSubmit`.

Spark and Hadoop are customer-provided runtimes and are intentionally not
bundled in the DataAI evaluation ZIP.

## Run

From the extracted package root:

```powershell
.\smoke-test\run-smoke-test.ps1
```

If the customer's Windows policy blocks direct script invocation and the
customer's security policy permits a process-only override, run:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File `
  .\smoke-test\run-smoke-test.ps1
```

This option applies only to that PowerShell process; it does not change the
computer's execution policy.

For an explicit executable path:

```powershell
.\smoke-test\run-smoke-test.ps1 `
  -SparkSubmit 'C:\spark\bin\spark-submit.cmd'
```

Success requires exit code `0` and a `DATAAI_*_SMOKE_TEST_PASS` marker. This
local check validates the delivered DataAI libraries. It does not replace the
documented validation on Databricks, AWS, Azure, Oracle, Google Cloud,
Tableau, Alteryx, or another customer-selected external platform.
