-- Execute after run-smoke-test.ps1 completes.

SELECT TOP 10
    run_id,
    status,
    rows_read,
    rows_accepted,
    rows_rejected,
    quality_score,
    platform
FROM DataAI.PipelineRuns
ORDER BY completed_at DESC;

SELECT COUNT(*) AS clean_rows FROM DataAI.CleanRows;
SELECT COUNT(*) AS rejected_rows FROM DataAI.RejectedRows;
SELECT COUNT(*) AS quality_findings FROM DataAI.QualityFindings;
SELECT COUNT(*) AS field_profiles FROM DataAI.FieldProfiles;
SELECT COUNT(*) AS matrix_rows FROM DataAI.MatrixBalance;
